package org.example;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;

public class App
{
    public static void main(String[] args) throws ParserConfigurationException
    {
        Element nodoEmp = null;
        Element nodoDat = null;
        Text info = null;

        //Creo documento
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();

        //Interfaz DOM
        DOMImplementation dom = db.getDOMImplementation();
        Document document = dom.createDocument(null,"xml",null);

        //Elemento raiz/nodriza
        Element raiz = document.createElement("empleados");
        document.getDocumentElement().appendChild(raiz);


        ArrayList<Empleado> empleados = new ArrayList<>();
        Empleado e1 = new Empleado(1,"Maria Hidalgo",2200);
        Empleado e2 = new Empleado(2,"Miguel Bas",1500);
        Empleado e3 = new Empleado(3,"Liobo Silva",1800);

        empleados.add(e1);
        empleados.add(e2);
        empleados.add(e3);

        //Cargo los datos al XML
        for (int i=0 ; i< document.getAttributes().getLength() ; i++)
        {
            //Nodo de la entidad menor
            nodoEmp = document.createElement("empleado");
            raiz.appendChild(nodoEmp);

            //Cada pasada, recoge variables y añade su valor a nodos adjuntos a entidad menor
            nodoDat = document.createElement("id");
            nodoEmp.appendChild(nodoDat);

            info = document.createTextNode(String.valueOf(empleado.getId()));
            nodoDat.appendChild(info);

            nodoDat = document.createElement("nombre");
            nodoEmp.appendChild(nodoDat);

            info = document.createTextNode(empleado.getNom());
            nodoDat.appendChild(info);

            nodoDat = document.createElement("salario");
            nodoEmp.appendChild(nodoDat);

            info = document.createTextNode(String.valueOf(empleado.getSalario()));
            nodoDat.appendChild(info);
        }

        //Establecemos fuente xml
        Source source = new DOMSource(document);
        Result resul = new StreamResult(new File("empleados1.xml"));

        //Transformación
        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty("indent","yes");
            transformer.transform(source,resul);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }



    }
}
