/*
1. Realiza una aplicación que genere un fichero de acceso directo con registros de una determinada entidad.
La aplicación debe permitir, al menos, generar altas y consultas.
1b) Prepara el programa para evitar colisiones mediante el área de sinónimos.
1c) Implementa métodos listar y eliminar.
 */

import java.util.Scanner;
import java.io.*;

public class Main
{
    private static final int maxTAM = 32;
    public static final int tam = (Integer.SIZE/8)+(Double.SIZE/8)+maxTAM;
    public static int id;
    public static String nombre;
    public static double salario;

    public static void main(String[] args)
    {
        Scanner ent = new Scanner(System.in);
        File f = new File("empresa.dat");

        int num;
        System.out.println("Programa que gestiona los trabajadores de una empresa. Elige una opción:");
        System.out.println("\t 1-Alta de empleado.\n\t 2-Consulta de empleado mediante ID.\n\t 3-Listado de empleados.\n\t 4-Baja de emplead0. \n\t 5-Cerrar programa.");
        num = ent.nextInt();

        while((num>0)&&(num<6))
        {
            switch(num)
            {
                case 1: Alta(); break;
                case 2: Consulta(); break;
                case 3: Listar(); break;
                case 4: Eliminar(); break;
                case 5: System.out.println("Cerrando programa."); return;
            }
            System.out.println("\t 1-Alta de empleado.\n\t 2-Consulta de empleado mediante ID.\n\t 3-Listado de empleados.\n\t 4-Baja de emplead0. \n\t 5-Cerrar programa.");
            num = ent.nextInt();
        }
        System.exit(0);
    }


    public static void Alta()
    {
        Scanner ent = new Scanner(System.in);
        try(RandomAccessFile raf = new RandomAccessFile("empresa.dat","rw"))
        {
            // Variables locales antes de guardar los datos
            System.out.println("Introduce el ID del empleado.");
            id = ent.nextInt();
            ent.nextLine();
            System.out.println("Introduce el nombre del empleado.");
            nombre = ent.nextLine();
            System.out.println("Introduce su salario.");
            salario = ent.nextDouble();
            ent.nextLine();

            //Posicionamos cursor y guardamos
            raf.seek(raf.length());

            raf.writeInt(id);
            raf.writeUTF(nombre);
            raf.writeDouble(salario);

            raf.close();


        }catch(IOException e){
            System.out.println("Error en el alta.");
        }
    }


    public static void Consulta()
    {
        Scanner ent = new Scanner(System.in);
        try(RandomAccessFile raf = new RandomAccessFile("empresa.dat", "r"))
        {
            System.out.println("Introduce el ID del empleado.");
            int id2 = ent.nextInt();

            //Posicionamos cursor y leemos primer valor
            raf.seek((tam-1) * maxTAM);
            id = raf.readInt();

            /*while(id != id2)
            {
                id = raf.readInt();
                nombre = raf.readLine();
                salario = raf.readDouble();
            }*/

            if(id == id2)
                System.out.println("\nID: "+ id +"\nNombre: " + nombre + "\nSalario" + salario);

            raf.close();

        }catch(IOException e){
            System.out.println("Error en la consulta.");
        }
    }

    public static void Listar()
    {

        try(RandomAccessFile raf = new RandomAccessFile("empresa.dat", "r");)
        {
            raf.seek((tam-1) * maxTAM);

            while(true)
            {
                id=raf.readInt();
                nombre=raf.readLine();
                salario=raf.readDouble();
                System.out.println("ID: "+ id +"\nNombre: " + nombre + "\nSalario "+ salario );
            }

            raf.close();
        }
        catch(EOFException e1)
        {
            //System.err.println();
        }
        catch(IOException e2)
        {
            System.err.println(e2.getMessage());
        }
    }

    public static void Eliminar()
    {
        int id2;
        String nombre2;
        double salario2;
        File f1 = new File("empresa.dat");
        File f2 = new File("empresa2.dat");

        try(RandomAccessFile raf = new RandomAccessFile("empresa.dat", "r");
            FileInputStream fis = new FileInputStream("peliculas.dat");
            DataInputStream dis = new DataInputStream(fis);
            FileOutputStream fos = new FileOutputStream("peliculas2.txt");
            DataOutputStream dos = new DataOutputStream(fos);
        )
        {
            id2=raf.readInt();
            nombre2=raf.readLine();
            salario2=raf.readDouble();

            while(true)
            {
                if(id2 != id)
                {
                    dos.writeInt(id2);
                    dos.writeUTF(nombre2);
                    dos.writeDouble(salario2);
                }

                id=dis.readInt();
                nombre=dis.readUTF();
                salario=dis.readDouble();
            }

        }catch(IOException e)
        {
            System.err.println(e.getMessage());
        }
        
        raf.close();

        f2.renameTo(f1);
    }


}