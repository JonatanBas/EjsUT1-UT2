package org.example;
//- Realiza un ejemplo de código susceptible de sufrir ataque por inyección de SQL.

import java.sql.*;

public class Injection
{

    public static void main(String[] args)
    {
        int id = 0;
        String nombre = null;
        Double salario = null;
        String jdbcURL = "jdbc:postgresql://172.22.0.2:5432/empleados";
        PreparedStatement sentencia = null;

        //EXECUTE CON STATEMENT PARA FORZAR EL ÉRROR POR INYECCIÓN
        try(Connection con = DriverManager.getConnection(jdbcURL,"root", "root");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = null;)
        {
            String sql = "SELECT * FROM empleados WHERE nombre='";
            st = con.Statement("update empleados set nombre=? where salario=?");
            rs.updateString(2,"Prueba Statement");
            rs.updateDouble(2,200);
            ResultSet rs = st.executeQuery(sql);

        }catch (SQLException e) {
            System.out.println("Fallo en el update");
        } catch (ClassNotFoundException e) {
            System.out.println("Fallo en el update");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Fallo en el update");
            }
        }

        //EXECUTE CON PREPARED STATEMENT PARA PREVENIR EL PROBLEMA
        try(Connection con = DriverManager.getConnection(jdbcURL,"root", "root");
            PreparedStatement ps =null;)
        {
            ps = conn.prepareStatement("update empleados set nombre=? where salario=?");
            ps.setString(1, "Prueba PreparedStament ");
            ps.setDouble(2, 1500);

            pstmt.executeUpdate();
            System.out.println("Modificado el producto!");

        }catch (SQLException e) {
            System.out.println(e.toString());
        } catch (ClassNotFoundException e) {
            System.out.println(e.toString());
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
    }
}
