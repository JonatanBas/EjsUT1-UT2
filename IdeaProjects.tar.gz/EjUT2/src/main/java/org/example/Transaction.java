package org.example;

public class Transaction
{
    public static void main(String[] args)
    {
        System.out.println("Ejemplo de transacción fallida");
        String nombre = null;
        Double salario = null;
        String jdbcURL = "jdbc:postgresql://172.22.0.2:5432/empleados";
        Connection con = null;
        PreparedStatement ps =null;
        ResultSet Gen = null;

        String rango = "analista";
        Double extraSalario = 500;

        try {
            con.setAutoCommit(false);
            int transferencia = 5000;
            int cuentaOrigen = 1;
            int cuentaDestino = 2;
            Statement sentenciaResta = conexion.createStatement ();
            sentenciaResta.executeUpdate( "UPDATE Comptes SET quantitat = quantitat -" + trans +
                    "WHERE NCuenta =" + cuentaOrigen);
            Statement sentenciaSuma = conexion.createStatement ();
            sentenciaSuma.executeUpdate( "UPDATE Comptes SET quantitat = quantitat +" + trans +
                    "WHERE NCuenta =" + cuentaDestino);
            conexion.commit();
            conexion.setAutoCommit(true);
        }
        catch (SQLException ex) {
            conexion.rollback();
            System.out.println( "La transacció ha fallat.");
            conexion.setAutoCommit(true);
        }

    }

}
