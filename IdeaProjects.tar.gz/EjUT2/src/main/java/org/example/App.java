package org.example;

import java.sql.*;

/*
 Crea un proyecto JDBC que genere una base de datos con tu nombre y, al menos, una tabla para el elemento
 con el que estés trabajando (discos, libros, videojuegos, etc).

 - Sobre un ResultSet de tdo el contenido de la tabla realiza al menos una inserción,
 una modificación y un borrado utilizando, al menos, 5 métodos de desplazamiento a lo largo del ResultSet.

 - Realiza un ejemplo de código susceptible de sufrir ataque por inyección de SQL.

 - Haz la variante que corrija el inconveniente anterior (haciendo uso de PreparedStatement).

 - Realiza una transacción que no se complete al provocar un rollback.

 - Utiliza al menos una función y un procedimiento. Adjunta el código de las funciones y procedimientos también.

 - Haz uso a lo largo del proyecto de un agrupamiento (pool) de conexiones.
 */

public class App 
{
    public static void main( String[] args )
    {
        int id = 0;
        String nombre = null;
        Double salario = null;
        String jdbcURL = "jdbc:postgresql://172.22.0.2:5432/empleados";
        String sentenciaSql = "INSERT INTO empleados (id, nombre, salario) VALUES (?, ?, ?)";
        PreparedStatement sentencia = null;

        //1) ResultSet
        try(Connection con = DriverManager.getConnection(jdbcURL, "root", "root");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs=st.executeQuery("select * from empleados");)
        {
            System.out.println("Conectando con la Base de Datos.");

            sentencia = con.prepareStatement(sentenciaSql);
            sentencia.setInt(1, id);
            sentencia.setString(2, nombre);
            sentencia.setDouble(2, salario);
            sentencia.executeUpdate();

            //INSERCIÓN
            //Creamos un nuevo registro en empleados
            System.out.println("Creamos un nuevo registro.");
            rs.moveToInsertRow();
            rs.updateInt(1,5);
            rs.updateString(2,"Jonatan");
            rs.updateDouble(3,1500);
            rs.insertRow();

            //MODIFICACIÓN
            System.out.println("Modificamos todo el tercer empleado.");
            rs.absolute(3);
            rs.updateInt(1,2);
            rs.updateString(2,"Sheila");
            rs.updateDouble(3,2000)
            rs.updateRow();

            //LECTURA
            System.out.println("Leemos el segundo empleado.");
            rs.relative(-1);
            id=rs.getInt("ID");
            nombre=rs.getString("serie");
            salario=rs.getDouble(3);
            System.out.println("RESULTADO DE LA CONSULTA: ");
            System.out.println("ID: "+ id + " Nombre: " + nombre + " Salario: "+ salario );


            //BORRADO
            //Con ResultSet, eliminamos el primer registro
            System.out.println("Borramos el primer registro.");
            rs.first();
            rs.deleteRow();


        }catch (SQLException sqle){
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
}
