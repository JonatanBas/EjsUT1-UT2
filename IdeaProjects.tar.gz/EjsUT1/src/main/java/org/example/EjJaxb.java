package org.example;

import javax.xml.bind.*;


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
class Empleado
{
    //Atributos
    private int id;
    private String nombre;
    private Double salario;

    //Builder
    public Empleado(int id, String nombre, Double salario) {
        this.id=id;
        this.nombre = nombre;
        this.salario = salario;
    }

    //Setters
    public void setId(int id){
        this.id=id;
    }
    public void setNombre (String nombre) {
        this.nombre = nombre;
    }
    public void setSalario(Double salario){
        this.salario=salario;
    }

    //Getters
    public int getId () {
        return id; }
    public String getNombre () {
        return nombre; }
    public Double getSalario () {
        return salario; }


    @XmlElement(name="Cobrar")
    public Double getSalario () {
        return salario; }

}

public class EjJaxb
{
    public static void main(String[] args)
    {
        try
        {
            //Creo objeto
            Empleado e = new Producto("Jaime",2);

            JAXBContext contexto = JAXBContext.newInstance(producto.getClass());
            Marshaller marshaller = contexto.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(empleado, System.out);
        }catch (PropertyException e)
        {
            e.printStackTrace();
        }catch (JAXBException e)
        {
            e.printStackTrace();
        }
    }
}